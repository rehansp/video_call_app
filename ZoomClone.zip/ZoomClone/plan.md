# plan of action

- Initialize our NodeJS Project DONE
- Initialize our first view DONE
- create a room id DONE
- Add the ability to view our own video DONE 
- Add the ability to allow others to stream their video
- Add styling 
- Add the ability to create messages
- Add mute button
- Add stop Video button
