// create video element and show your own video 

//const { Socket } = require("socket.io");
const socket = io('/');
const videoGrid = document.getElementById('video-grid');
const myvideo = document.createElement('video'); // creating video element(html element)
myvideo.muted = true; // i'm going to mute this video 

var peer = new Peer(undefined, {
    path: '/peerjs',
    host: '/',
    port: 3030 // reason is now nodejs server is on 3030
}); //creatng new peer //id is going to be connected automatically

let myVideoStream  // this variable can be globally accessed
navigator.mediaDevices.getUserMedia({  // getUserMedia will accept an object to create our own video
     video: true, // first object will be video 
     audio: true
 }).then(stream => {
     myVideoStream = stream; // video stream will receive the stream
     addVideoStream(myvideo, stream); // adding video element //it has two parameters namely video element and stream

     peer.on('call', call =>{
         call.answer(stream)
         const video = document.createElement('video')
         call.on('stream', userVideoStream => {
            addVideoStream(video, userVideoStream)
         })
     })

     socket.on('user-connected', (userId) => {
        connecToNewUser(userId, stream);
    }) 
 })

peer.on('open', id => {
    // console.log(id); // specific id for user connecting
    socket.emit('join-room', ROOM_ID, id); // joining the room
})  


const connecToNewUser = (userId, stream) => {
    const call = peer.call(userId, stream)
    const video = document.createElement('video')
    call.on('stream', userVideoStream => {
        addVideoStream(video, userVideoStream)
    })
} 

const addVideoStream = (video, stream) => {
    video.srcObject = stream;
    video.addEventListener('loadedmetadata', () => {
        video.play();
    })
    videoGrid.append(video)
}

  