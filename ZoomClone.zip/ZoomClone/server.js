const express = require('express');
const app = express();
const server = require('http').Server(app); // creating server
const { v4: uuidV4 } = require('uuid');
const { ExpressPeerServer } = require('peer');
const peerServer = ExpressPeerServer(server, {
  debug: true
}); // using peerserver with express server 
const io = require('socket.io')(server) // importing socket.io
app.set('view engine', 'ejs'); // we need to tell express to set view engine ejs
app.use(express.static('public')); // static folder

app.use('/peerjs', peerServer); // url going to use for peerserver

app.get('/', (req, res) => {
    //res.status(200).send("Hello World");
    //res.render('room'); // we are going to render room(html file) // make sure you have installed ejs
    res.redirect(`/${uuidV4()}`); // we go to localhost 3030 it will generate uuid and redirect you to it. 
})

app.get('/:room', (req, res) => {
    res.render('room', { roomId: req.params.room }); // roomId parameter
}) 

io.on('connection', socket => {
    socket.on('join-room', (roomId, userId) => {
        //console.log("joined room");
        socket.join(roomId);
        socket.to(roomId).broadcast.emit('user-connected', userId);
    })
})

server.listen(3030); // server listening on port 3030 and server will be local host
